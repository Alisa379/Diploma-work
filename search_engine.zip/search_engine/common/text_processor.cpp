#include "text_processor.h"

#include <boost/locale.hpp>

namespace bl = boost::locale;

namespace {

// Длина строки в символах Unicode (а не в байтах UTF-8)
std::size_t utf8Length(const std::string& s) {
    std::size_t length = 0;
    for (unsigned char c : s) {
        if ((c & 0xC0) != 0x80) {  // не байт-продолжение
            ++length;
        }
    }
    return length;
}

}  // namespace

TextProcessor::TextProcessor() {
    bl::generator gen;
    locale_ = gen("ru_RU.UTF-8");
}

std::vector<std::string> TextProcessor::extractWords(const std::string& text) const {
    // Отбрасываем некорректные последовательности UTF-8, чтобы файл в другой
    // кодировке или бинарный мусор не приводили к исключению
    const std::string valid = bl::conv::utf_to_utf<char>(text, bl::conv::skip);
    const std::string lower = bl::to_lower(valid, locale_);

    // Разбиение на слова по правилам Unicode: знаки препинания, пробелы,
    // табуляция и переводы строк в выборку не попадают
    bl::boundary::ssegment_index index(bl::boundary::word, lower.begin(), lower.end(), locale_);
    index.rule(bl::boundary::word_letters | bl::boundary::word_number |
               bl::boundary::word_kana | bl::boundary::word_ideo);

    std::vector<std::string> words;
    for (const auto& segment : index) {
        std::string word = segment.str();
        const std::size_t length = utf8Length(word);
        if (length >= kMinWordLength && length <= kMaxWordLength) {
            words.push_back(std::move(word));
        }
    }
    return words;
}

std::unordered_map<std::string, int> TextProcessor::countWords(const std::string& text) const {
    std::unordered_map<std::string, int> frequency;
    for (auto& word : extractWords(text)) {
        ++frequency[std::move(word)];
    }
    return frequency;
}
